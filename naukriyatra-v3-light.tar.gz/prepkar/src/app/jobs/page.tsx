"use client";
import { useState, useEffect, Suspense } from "react";
import { useSearchParams } from "next/navigation";
import Link from "next/link";
import BottomNav from "@/components/BottomNav";
import { JOBS, JOB_CATEGORIES, type Job } from "@/components/data";

function JobSheet({ job, onClose }: { job: Job; onClose: () => void }) {
  const [tab, setTab] = useState<"roadmap"|"life"|"impact">("roadmap");
  return (
    <div style={{ position:"fixed",inset:0,zIndex:100 }}>
      <div onClick={onClose} style={{ position:"absolute",inset:0,background:"rgba(0,0,0,0.5)",backdropFilter:"blur(6px)" }} />
      <div style={{ position:"absolute",bottom:0,left:0,right:0,background:"#fff",borderRadius:"24px 24px 0 0",maxHeight:"93vh",overflow:"auto",paddingBottom:32 }}>
        <div style={{ display:"flex",justifyContent:"center",padding:"10px 0 4px" }}><div style={{ width:36,height:4,borderRadius:4,background:"#ddd" }} /></div>
        <div style={{ padding:"0 20px" }}>
          <div style={{ display:"flex",gap:5,marginBottom:8 }}>
            {job.isNew && <span style={{ background:"#0C7C59",color:"#fff",fontSize:9,fontWeight:700,padding:"2px 8px",borderRadius:10 }}>NEW</span>}
            {job.isHot && <span style={{ background:"#dc2626",color:"#fff",fontSize:9,fontWeight:700,padding:"2px 8px",borderRadius:10 }}>🔥 TRENDING</span>}
          </div>
          <h2 style={{ fontFamily:"'Playfair Display',serif",fontSize:22,fontWeight:800,color:"var(--text-dark)",lineHeight:1.25,marginBottom:2 }}>{job.title}</h2>
          <p style={{ fontSize:12,color:"var(--text-light)",marginBottom:16 }}>{job.org}</p>

          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:8,marginBottom:18 }}>
            {[{l:"Vacancies",v:job.vacancies.toLocaleString(),i:"👥"},{l:"In-Hand Salary",v:job.inHand,i:"💰"},{l:"Last Date",v:job.lastDate,i:"📅"},{l:"Post",v:job.grade.length>30?job.grade.slice(0,30)+"…":job.grade,i:"📊"}].map((s,i)=>(
              <div key={i} style={{ background:"#F8F9FC",borderRadius:10,padding:"10px 12px" }}>
                <div style={{ fontSize:10,color:"var(--text-light)",marginBottom:2 }}>{s.i} {s.l}</div>
                <div style={{ fontSize:12,fontWeight:600,color:"var(--text-dark)" }}>{s.v}</div>
              </div>
            ))}
          </div>

          {/* Tabs */}
          <div style={{ display:"flex",gap:3,marginBottom:18,background:"#F4F5F7",borderRadius:10,padding:3 }}>
            {(["roadmap","life","impact"] as const).map(t=>(
              <button key={t} onClick={()=>setTab(t)} style={{
                flex:1,padding:"9px 0",borderRadius:8,fontSize:12,fontWeight:600,border:"none",cursor:"pointer",transition:"all 0.2s",
                background:tab===t?"#fff":"transparent",color:tab===t?"var(--text-dark)":"var(--text-light)",
                boxShadow:tab===t?"var(--shadow-sm)":"none",
              }}>{t==="roadmap"?"Roadmap":t==="life"?"Life & Salary":"Your Impact"}</button>
            ))}
          </div>

          {/* ROADMAP TAB */}
          {tab==="roadmap" && (
            <div className="anim-fade">
              <p style={{ fontSize:13,color:"var(--text-body)",marginBottom:18,lineHeight:1.5 }}>Your step-by-step journey to this career:</p>
              {/* Premium timeline */}
              <div style={{ position:"relative",paddingLeft:36 }}>
                <div style={{ position:"absolute",left:14,top:12,bottom:12,width:2,background:"linear-gradient(to bottom,#0C7C59,#0C7C5920)",borderRadius:2 }} />
                {job.roadmap.map((r,i)=>(
                  <div key={i} style={{ position:"relative",marginBottom:i===job.roadmap.length-1?0:24 }}>
                    <div style={{
                      position:"absolute",left:-28,top:2,width:24,height:24,borderRadius:"50%",
                      background:i===job.roadmap.length-1?"#0C7C59":"#fff",
                      border:"2.5px solid #0C7C59",display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,
                      color:i===job.roadmap.length-1?"#fff":"#0C7C59",boxShadow:"0 2px 8px rgba(12,124,89,0.15)",
                    }}>{r.icon}</div>
                    <div style={{ background:"#F8FAF9",borderRadius:12,padding:"12px 14px",border:"1px solid #E5EDE9" }}>
                      <div style={{ fontSize:14,fontWeight:700,color:"var(--text-dark)",marginBottom:2 }}>{r.step}</div>
                      <div style={{ fontSize:12,color:"var(--text-body)",lineHeight:1.5 }}>{r.detail}</div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Promotion Path */}
              <h3 style={{ fontFamily:"'Playfair Display',serif",fontSize:17,fontWeight:700,color:"var(--text-dark)",marginTop:28,marginBottom:12 }}>Promotion & Salary Growth</h3>
              <div style={{ display:"flex",flexDirection:"column",gap:6 }}>
                {job.promotionPath.map((p,i)=>(
                  <div key={i} style={{
                    display:"flex",alignItems:"center",justifyContent:"space-between",
                    background:i===0?"linear-gradient(135deg,#0C7C5908,#0C7C5912)":"#F8F9FC",
                    borderRadius:10,padding:"12px 14px",
                    border:i===0?"1px solid #0C7C5930":"1px solid var(--border)",
                  }}>
                    <div>
                      <div style={{ fontSize:13,fontWeight:700,color:"var(--text-dark)" }}>{p.title}</div>
                      <div style={{ fontSize:11,color:"var(--text-light)" }}>{p.years}</div>
                    </div>
                    <div style={{ fontSize:14,fontWeight:800,color:"#0C7C59",fontFamily:"'Outfit'" }}>{p.salary}</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* LIFE TAB */}
          {tab==="life" && (
            <div className="anim-fade">
              <Block color="#2563eb" icon="🏠" title="Life After Selection" text={job.lifestyle} />
              <Block color="#7c3aed" icon="📋" title="A Typical Day" text={job.dayInLife} />
              <Block color="#0C7C59" icon="💡" title="Why People Choose This" text={job.whyChoose} />
              <Block color="#ea580c" icon="⚡" title="Challenges & Reality" text={job.challenges} />
              <div style={{ borderRadius:12,padding:"14px",marginBottom:14,background:"#FFF8F0",border:"1px solid #FDE8D0" }}>
                <div style={{ fontSize:10,fontWeight:700,color:"#d97706",letterSpacing:1,textTransform:"uppercase",marginBottom:8 }}>🎁 Benefits & Perks</div>
                <div style={{ display:"flex",flexWrap:"wrap",gap:5 }}>
                  {job.benefits.map((b,i)=>(<span key={i} style={{ background:"#FEF3E2",color:"#92400e",fontSize:10,padding:"4px 9px",borderRadius:6,fontWeight:500 }}>✓ {b}</span>))}
                </div>
              </div>
            </div>
          )}

          {/* IMPACT TAB */}
          {tab==="impact" && (
            <div className="anim-fade">
              <div style={{
                background:"linear-gradient(135deg,#EFF6FF,#F0F9FF)",borderRadius:16,padding:"20px 18px",
                border:"1px solid #DBEAFE",marginBottom:16,
              }}>
                <div style={{ fontSize:28,marginBottom:10,textAlign:"center" }}>🇮🇳</div>
                <h3 style={{ fontFamily:"'Playfair Display',serif",fontSize:17,fontWeight:700,color:"var(--text-dark)",textAlign:"center",marginBottom:10 }}>How You Serve the Nation</h3>
                <p style={{ fontSize:13,color:"var(--text-body)",lineHeight:1.7 }}>{job.impact}</p>
              </div>
              <Block color="#0C7C59" icon="📋" title="Eligibility" text={job.eligibility} />
              <Block color="#7c3aed" icon="📝" title="Exam Stages" text={job.exam} />
            </div>
          )}

          <Link href="/interview" style={{ textDecoration:"none" }}>
            <div style={{ width:"100%",padding:"14px",marginTop:20,background:"#0C7C59",borderRadius:12,fontSize:14,fontWeight:700,color:"#fff",textAlign:"center",boxShadow:"0 4px 16px rgba(12,124,89,0.3)" }}>
              🎯 Practice Interview for This Role
            </div>
          </Link>
        </div>
      </div>
    </div>
  );
}

function Block({ color,icon,title,text }:{ color:string;icon:string;title:string;text:string }) {
  return (
    <div style={{ borderRadius:12,padding:"14px",marginBottom:12,background:`${color}06`,borderLeft:`3px solid ${color}` }}>
      <div style={{ fontSize:10,fontWeight:700,color,letterSpacing:1,textTransform:"uppercase",marginBottom:6 }}>{icon} {title}</div>
      <div style={{ fontSize:12,color:"var(--text-body)",lineHeight:1.7,whiteSpace:"pre-line" }}>{text}</div>
    </div>
  );
}

function JobsInner() {
  const params = useSearchParams();
  const [filter,setFilter] = useState("all");
  const [sel,setSel] = useState<Job|null>(null);
  useEffect(()=>{ const id=params.get("id"); if(id){ const f=JOBS.find(j=>j.id===id); if(f) setSel(f); } },[params]);
  const list = filter==="all"?JOBS:JOBS.filter(j=>j.category===filter);

  return (
    <main style={{ minHeight:"100vh",background:"var(--bg)",paddingBottom:76 }}>
      <header style={{ position:"sticky",top:0,zIndex:40,padding:"12px 16px",background:"rgba(250,251,253,0.95)",backdropFilter:"blur(16px)",borderBottom:"1px solid var(--border)" }}>
        <div style={{ display:"flex",alignItems:"center",gap:8,marginBottom:10 }}>
          <Link href="/" style={{ color:"var(--text-light)",fontSize:13,textDecoration:"none" }}>←</Link>
          <h1 style={{ fontFamily:"'Playfair Display',serif",fontSize:20,fontWeight:700,color:"var(--text-dark)" }}>Explore Careers</h1>
        </div>
        <div className="no-scroll" style={{ display:"flex",gap:5,overflowX:"auto" }}>
          <Pill label={`All (${JOBS.length})`} on={filter==="all"} color="#0C7C59" click={()=>setFilter("all")} />
          {JOB_CATEGORIES.map(c=>{ const n=JOBS.filter(j=>j.category===c.id).length; return n?<Pill key={c.id} label={`${c.icon} ${c.label}`} on={filter===c.id} color={c.color} click={()=>setFilter(c.id)} />:null; })}
        </div>
      </header>
      <div style={{ maxWidth:560,margin:"0 auto",padding:"14px 16px" }}>
        <p style={{ fontSize:12,color:"var(--text-light)",marginBottom:14 }}>Tap any career to see the complete roadmap, lifestyle, and how you serve the nation.</p>
        {list.map(job=>(
          <div key={job.id} onClick={()=>setSel(job)} style={{ background:"var(--bg-card)",borderRadius:14,padding:"16px",border:"1px solid var(--border)",boxShadow:"var(--shadow-sm)",cursor:"pointer",marginBottom:10,transition:"box-shadow 0.2s" }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start" }}>
              <div style={{ flex:1 }}>
                <div style={{ display:"flex",gap:5,marginBottom:4 }}>
                  {job.isNew && <span style={{ background:"#0C7C59",color:"#fff",fontSize:9,fontWeight:700,padding:"2px 7px",borderRadius:8 }}>NEW</span>}
                  {job.isHot && <span style={{ background:"#dc2626",color:"#fff",fontSize:9,fontWeight:700,padding:"2px 7px",borderRadius:8 }}>🔥 TRENDING</span>}
                </div>
                <div style={{ fontSize:15,fontWeight:700,color:"var(--text-dark)",lineHeight:1.3 }}>{job.title}</div>
                <div style={{ fontSize:11,color:"var(--text-light)",marginTop:2 }}>{job.org}</div>
              </div>
              <div style={{ textAlign:"right",flexShrink:0,marginLeft:12 }}>
                <div style={{ fontSize:18,fontWeight:800,color:"#0C7C59",fontFamily:"'Outfit'" }}>{job.vacancies.toLocaleString()}</div>
                <div style={{ fontSize:9,color:"var(--text-light)",textTransform:"uppercase" }}>posts</div>
              </div>
            </div>
            <div style={{ display:"flex",gap:12,marginTop:8 }}>
              <span style={{ fontSize:11,color:"var(--text-body)" }}>💰 {job.inHand}/mo</span>
              <span style={{ fontSize:11,color:"var(--text-body)" }}>📅 {job.lastDate}</span>
            </div>
            <div style={{ fontSize:11,color:"#0C7C59",marginTop:8,fontWeight:600 }}>Roadmap · Lifestyle · Impact →</div>
          </div>
        ))}
      </div>
      {sel && <JobSheet job={sel} onClose={()=>setSel(null)} />}
      <BottomNav />
    </main>
  );
}

function Pill({ label,on,color,click }:{ label:string;on:boolean;color:string;click:()=>void }) {
  return <button onClick={click} style={{ padding:"5px 13px",borderRadius:14,fontSize:11,fontWeight:600,border:"none",cursor:"pointer",flexShrink:0,whiteSpace:"nowrap",background:on?color:"#F0F2F5",color:on?"#fff":"var(--text-light)",transition:"all 0.2s" }}>{label}</button>;
}

export default function JobsPage() { return <Suspense><JobsInner /></Suspense>; }
